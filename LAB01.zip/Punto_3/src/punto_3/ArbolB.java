/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package punto_3;

/**
 *
 * @author Doriano
 */
public class ArbolB {
     NodoArbolB root;
    int t;

    public ArbolB(int t) {
        this.t = t;
        root = new NodoArbolB(t);
    }

    public int buscarClaveMayor() {
        int claveMaxima = getClaveMayor(this.root);

        return claveMaxima;
    }

    private int getClaveMayor(NodoArbolB current) {
        if (current == null) { //Si es cero no existe significa que no existe
        }

        while (!current.leaf) {
            current = current.child[current.n]; //Con esto se accede al hijo mas a la derecha
        }

        return claveMayorPorNodo(current);
    }

    private int claveMayorPorNodo(NodoArbolB current) { //Devuelve el valor mayor (el que esta mas a la derecha)
        return current.key[current.n - 1];
    }
    public void mostrarClavesNodoMinimo() {
        NodoArbolB temp = buscarNodoMinimo(root);

        if (temp == null) {
            System.out.println("Sin minimo");
        } else {
            temp.imprimir();
        }
    }
    public NodoArbolB buscarNodoMinimo(NodoArbolB nodoActual) {
        if (root == null) {
            return null;
        }

        NodoArbolB aux = root;

        
        while (!aux.leaf) { //Se hace un while, hasta que no sea una hoja
            aux = aux.child[0];
        }
        return aux; //Devuelve el nodo menor (el que esta mas a la izquierda)
    }
    public void buscarNodoPorClave(int num) {
        NodoArbolB temp = search(root, num);

        if (temp == null) {
            System.out.println("No se ha encontrado un nodo con el valor ingresado");
        } else {
            print(temp);
        }
    }

    private NodoArbolB search(NodoArbolB actual, int key) {
        int i = 0;      //Comienza a buscar desde la primera posicion

        while (i < actual.n && key > actual.key[i]) {
            i++;
        }

        
        if (i < actual.n && key == actual.key[i]) { //Si es igual, se retorna
            return actual;
        }
    
        if (actual.leaf) {  //Se valida si tiene hijos
            return null;
        } else { //Si tiene hijos, hace una llamada recursiva
            return search(actual.child[i], key);
        }
    }

    public void insertar(int key) {
        NodoArbolB r = root;

        
        if (r.n == ((2 * t) - 1)) { //Se valida si el nodo esta lleno, lo debe separar antes de insertar
            NodoArbolB s = new NodoArbolB(t);
            root = s;
            s.leaf = false;
            s.n = 0;
            s.child[0] = r;
            split(s, 0, r);
            nonFullInsert(s, key);
        } else {
            nonFullInsert(r, key);
        }
    }
    
    private void split(NodoArbolB x, int i, NodoArbolB y) {
        
        NodoArbolB z = new NodoArbolB(t); //se guarda en un nodo temporal el hijo i+1 de x
        z.leaf = y.leaf;
        z.n = (t - 1);

        
        for (int j = 0; j < (t - 1); j++) { //En este for se copia las ultimas (t - 1) claves del nodo y al inicio del nodo z
            z.key[j] = y.key[(j + t)];
        }

        if (!y.leaf) { //se valida si no es hoja, si es asi hay que reasignar los nodos hijos
            for (int k = 0; k < t; k++) {
                z.child[k] = y.child[(k + t)];
            }
        }
        y.n = (t - 1);                                                                                                                     
        //Se mueve los hijos de x para darle espacio a z
        for (int j = x.n; j > i; j--) {
            x.child[(j + 1)] = x.child[j];
        }
        
        x.child[(i + 1)] = z;                                                 
        
        for (int j = x.n; j > i; j--) { //en este for se mueven las claves de x
            x.key[(j + 1)] = x.key[j];
        }

        x.key[i] = y.key[(t - 1)];   //con esto se agrega la clave situada en la mediana                                                          /    \
        x.n++;                                                                  
    }

    private void nonFullInsert(NodoArbolB x, int key) {
        
        if (x.leaf) { //se valida si es una hoja
            int i = x.n; //cantidad de valores del nodo
            
            while (i >= 1 && key < x.key[i - 1]) { //busca la posicion i donde asignar el valor
                x.key[i] = x.key[i - 1]; //Desplaza los valores mayores a key
                i--;
            }

            x.key[i] = key;//asigna el valor al nodo
            x.n++;
        } else {
            int j = 0;
            
            while (j < x.n && key > x.key[j]) { //Busca la posicion del hijo
                j++;
            }

            
            if (x.child[j].n == (2 * t - 1)) { //Si el nodo hijo esta lleno lo separa
                split(x, j, x.child[j]);

                if (key > x.key[j]) {
                    j++;
                }
            }

            nonFullInsert(x.child[j], key);
        }
    }

    public void showBTree() {
        print(root);
    }

    //preorder
    private void print(NodoArbolB n) {
        n.imprimir();
        
        if (!n.leaf) {
            for (int j = 0; j <= n.n; j++) {
                if (n.child[j] != null) {
                    System.out.println();
                    print(n.child[j]);
                }
            }
        }
    }
}
