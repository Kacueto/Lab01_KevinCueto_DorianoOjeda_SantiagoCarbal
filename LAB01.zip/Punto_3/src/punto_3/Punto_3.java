/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package punto_3;
import java.util.Random;
/**
 *
 * @author Doriano
 */
public class Punto_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int t = 7; //t es el grado minimo del Arbol
        ArbolB arbolB = new ArbolB(t);
        // random para crear lo gastado en los 2 meses
        int[] Gastado = new int[60];
        Random nRandom = new Random();
        for(int i=0; i<Gastado.length; i++) {
            Gastado[i] = nRandom.nextInt(25001);
        }
        System.out.println("insertando valores al arbol B");
        for(int i=0; i<Gastado.length; i++) {
            System.out.println("Insertando el valor: " + Gastado[i]);
            arbolB.insertar(Gastado[i]);
        }
        
        //Mostrando arbol en preorder
        System.out.println("Arbol B");
        arbolB.showBTree();
        System.out.println("");

        //Buscar
        System.out.println("\nBuscando el nodo con el valor 10000 en el arbol B:");
        arbolB.buscarNodoPorClave(10000);
        
        //Buscar valor mayor
        System.out.println("\nEl valor maximo del arbol B es : " + arbolB.buscarClaveMayor());
        
        System.out.print("Los nodos minimos de la raiz del arbol B es :");
        arbolB.mostrarClavesNodoMinimo();
        
        System.out.println("");
        System.out.println("Fin de la ejecución");
    }
    
}
