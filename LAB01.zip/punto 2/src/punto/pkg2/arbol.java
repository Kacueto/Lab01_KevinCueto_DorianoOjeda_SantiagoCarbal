package punto.pkg2;

public class arbol {

    nodo raiz;
    int tamaño;

    public arbol() {

        raiz = null;

    }

    public void insertar(int dato) {
        if (raiz == null) {
            raiz = new nodo(dato);
            tamaño++;
        } else {
            boolean band = true;
            nodo aux = raiz;
            while (band) {
                if (dato < aux.dato) {
                    if (aux.izq != null) {

                        aux = aux.izq;

                    } else {
                        aux.izq = new nodo(dato, aux);
                        tamaño++;
                        band = false;
                    }

                } else if (dato > aux.dato) {
                    if (aux.der != null) {
                        aux = aux.der;
                    } else {
                        aux.der = new nodo(dato, aux);
                        tamaño++;
                        band = false;
                    }
                }
            }

        }
    }
    //creo la funcion para devolver el nodo padre del nodo con el menor dato
    public nodo padremenor(nodo raiz) {
        //creo una variable auxiliar
        nodo aux = raiz;
        // recorro todo el lado izquierdo del arbol hasta llegar al menor de todos 
        while (aux.izq != null) {
            aux = aux.izq;
        }
        //le hago return al padre del menor ya encontrado en el while
        return aux.raiz;

    }
    //creo la funcion para devolver el nodo padre del nodo con el mayor dato
    public nodo padremayor(nodo raiz) {
        //creo una variable auxiliar
        nodo aux = raiz;    
        // recorro todo el lado derecho del arbol hasta llegar al mayor de todos
        while (aux.der != null) {
            aux = aux.der;
        }
        //le hago return al padre del mayor ya encontrado en el while
        return aux.raiz;
    }
    //creo la funcion para devolver el nivel de un nodo
    public int nivel(nodo nodo) {
        //creo un auxiliar
        int aux = 0;
        //recorro desde el nodo dado hasta la raiz de todo el arbol usando la funcion del arbol nodo.raiz
        while (nodo.raiz != null) {
            //aumento el contador auxiliar que sera al final el nivel del nodo 
            aux++;
            //viajo al nodo padre del nodo actual
            nodo = nodo.raiz;
        }
        //retorno el aux que viene siendo el nivel del nodo dado 
        return aux;
    }

}
