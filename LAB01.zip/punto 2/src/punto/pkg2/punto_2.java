package punto.pkg2;

public class punto_2 {

    public static void main(String[] args) {
        arbol arbol = new arbol();

        arbol.insertar(15);
        arbol.insertar(9);
        arbol.insertar(20);
        arbol.insertar(6);
        arbol.insertar(14);
        arbol.insertar(17);
        arbol.insertar(64);
        arbol.insertar(13);
        arbol.insertar(26);
        arbol.insertar(72);
        arbol.insertar(2);
        arbol.insertar(1);

        nodo PadreMenor = arbol.padremenor(arbol.raiz);
        System.out.println("el dato del padre del menor es:");
        System.out.println(PadreMenor.dato);
        nodo PadreMayor = arbol.padremayor(arbol.raiz);
        System.out.println("el dato del padre del mayor es:");
        System.out.println(PadreMayor.dato);
        int nivelPadreMenor = arbol.nivel(PadreMenor);
        System.out.println("el nivel del padre del menor es:");
        System.out.println(nivelPadreMenor);
        int nivelPadreMayor = arbol.nivel(PadreMayor);
        System.out.println("el nivel del padre del mayor es:");
        System.out.println(nivelPadreMayor);
    }

}
