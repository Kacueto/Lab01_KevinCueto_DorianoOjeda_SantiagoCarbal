/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package punto.pkg2;

/**
 *
 * @author kacueto
 */
public class nodo {
    int dato;
    nodo izq;
    nodo der;
    nodo raiz;
    public nodo(int dato){
        this.dato = dato;
        izq = null;
        der = null;
        
        
    }
     public nodo(int dato, nodo raiz){
        this.dato = dato;
        izq = null;
        der = null;
        
        
    }
}
