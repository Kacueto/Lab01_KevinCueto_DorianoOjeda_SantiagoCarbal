
public class Arbol_Avl {
    // declaro nodo raiz
    Nodo raiz;
    //funcion para leer altura de un nodo
    int altura(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }
        return nodo.altura;
    }
    //funcion para ver el mayor entre 2 numeros
    int maximo(int x, int z) {
        return (x > z) ? x : z;
    }
    //funcion que realiza la rotacion a la derecha 
    Nodo rotacionDer(Nodo nodo) {
        Nodo aux = nodo.izq;
        Nodo aux2 = aux.der;
        aux.der = nodo;
        nodo.izq = aux2;
        nodo.altura = maximo(altura(nodo.izq), altura(nodo.der)) + 1;
        aux.altura = maximo(altura(aux.izq), altura(aux.der)) + 1;
        return aux;

    }
    //funcion que realiza la rotacion a la izquierda simple
    Nodo rotacionIzq(Nodo nodo) {
        Nodo aux = nodo.der;
        Nodo aux2 = aux.izq;
        aux.izq = nodo;
        nodo.der = aux2;
        nodo.altura = maximo(altura(nodo.izq), altura(nodo.der)) + 1;
        aux.altura = maximo(altura(aux.izq), altura(aux.der)) + 1;
        return aux;
    }
    //resta la altura del hijo izquierdo de un nodo con la altura del hijo derecho para encontrar el factor del balanceo
    int factorDeBalanceo(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }
        return altura(nodo.izq) - altura(nodo.der);
    }
    //inserta un nodo como si fuese un abb y al momento de haber puesto el nodo comienza a verificar si el arbol esta balanceado y lo balancea por si mismo.
    Nodo insertar(Nodo nodo, int dato) {
        if (nodo == null) {
            return (new Nodo(dato));
        }
        if (dato < nodo.dato) {
            nodo.izq = insertar(nodo.izq, dato);
        } else if (dato > nodo.dato) {
            nodo.der = insertar(nodo.der, dato);
        } else {
            return nodo;
        }
        nodo.altura = 1 + maximo(altura(nodo.izq), altura(nodo.der));
        int factordebalanceo = factorDeBalanceo(nodo);
        //si el factor de balanceo es mayor a 1 significa que hay un desbalance y verifica de que lado es
        if (factordebalanceo > 1) {
            //si el desbalance es a la derecha hace unicamente una rotacion a la derecha simple
            if (dato < nodo.izq.dato) {
                return rotacionDer(nodo);
                //hace doble rotacion derecha
            } else if (dato > nodo.izq.dato) {
                nodo.izq = rotacionIzq(nodo.izq);
                return rotacionDer(nodo);
            }
        }
        if (factordebalanceo < -1) {
            if (dato > nodo.der.dato) {
                return rotacionIzq(nodo);
            } else if (dato < nodo.der.dato) {
                nodo.der = rotacionDer(nodo.der);
                return rotacionIzq(nodo);
            }
        }
        return nodo;
    }
    //busca el sucesor de un nodo para utilizarlo para ordenar el arbol cuando se elimine un nodo
    Nodo nodoMenor(Nodo nodo) {
        Nodo aux = nodo;
        while (aux.izq != null) {
            aux = aux.izq;
        }
        return aux;
    }
    //primero busca el nodo, luego lo elimina y tiene en cuenta cuantos hijos tenias a ver que tipo de eliminacion se hara, si tiene 2 hijos utiliza el sucesor para asi ponerlo como el nuevo nodo n
    Nodo Eliminar(Nodo nodo, int dato) {
        if (nodo == null) {
            return nodo;
        }
        if (dato < nodo.dato) {
            nodo.izq = Eliminar(nodo.izq, dato);
        } else if (dato > nodo.dato) {
            nodo.der = Eliminar(nodo.der, dato);
        } else {
            if ((nodo.izq == null) || (nodo.der == null)) {
                Nodo aux = null;
                if (aux == nodo.izq) {
                    aux = nodo.der;
                } else {
                    aux = nodo.izq;
                }
                if (aux == null) {
                    aux = nodo;
                    nodo = null;
                } else {
                    nodo = aux;
                }
            } else {
                Nodo aux = nodoMenor(nodo.der);
                nodo.dato = aux.dato;
                nodo.der = Eliminar(nodo.der, aux.dato);
            }

        }
        if (nodo == null) {
            return nodo;
        }
        nodo.altura = 1 + maximo(altura(nodo.izq), altura(nodo.der));
        int factordebalanceo = factorDeBalanceo(nodo);
        if (factordebalanceo > 1) {
            if (dato < nodo.izq.dato) {
                return rotacionDer(nodo);
            } else if (dato > nodo.izq.dato) {
                nodo.izq = rotacionIzq(nodo.izq);
                return rotacionDer(nodo);
            }
        }
        if (factordebalanceo < -1) {
            if (dato > nodo.der.dato) {
                return rotacionIzq(nodo);
            } else if (dato < nodo.der.dato) {
                nodo.der = rotacionDer(nodo.der);
                return rotacionIzq(nodo);
            }
        }
        return nodo;
    }
   // busca un nodo en especifico por su dato
    Boolean Buscar(int dato) {
        Nodo aux = raiz;

        while (aux != null) {
            if (dato == aux.dato) {
                return true;
            } else if (dato < aux.dato) {
                aux = aux.izq;
            } else if (dato > aux.dato) {
                aux = aux.der;
            }
        }
        return false;
    }
    //recorrido en inorden para verificar la eliminacion
    void inorden(Nodo nodo) {
        if (nodo != null) {
            inorden(nodo.izq);
            System.out.print(nodo.dato + " ");
            inorden(nodo.der);
        }

    }
    //realiza recorrido por nivel del arbol de manera recursiva
    void porNivel() {
        int altura = altura(raiz);
        for (int i = 1; i <= altura; i++) {
            nivel(raiz, i);
        }
    }

    private void nivel(Nodo nodo, int i) {
        if (nodo == null) {

            return;
        }
        if (i == 1) {
            System.out.print(nodo.dato + " ");

        } else if (i > 1) {
            nivel(nodo.izq, i - 1);
            nivel(nodo.der, i - 1);
        }

    }

    Nodo nodoDe(int dato) {
        Nodo aux = raiz;
        while (aux != null) {
            if (dato == aux.dato) {
                return aux;
            } else if (dato < aux.dato) {
                aux = aux.izq;
            } else if (dato > aux.dato) {
                aux = aux.der;
            }
        }
        return null;
    }

   
}
