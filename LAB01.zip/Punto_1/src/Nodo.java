/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kevin
 */
public class Nodo {
    int dato;
    int altura;
    Nodo izq;
    Nodo der;
    Nodo raiz;

    public Nodo(int dato) {
        this.dato = dato;
        this.altura = 1;
    }
    public Nodo(int dato, Nodo raiz) {
        this.dato = dato;
        this.altura = 1;
        this.raiz = raiz;
        
    }
}
