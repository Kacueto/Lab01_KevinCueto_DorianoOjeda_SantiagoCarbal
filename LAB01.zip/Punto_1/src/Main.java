/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kevin
 */
public class Main {
    public static void main(String[] args) {
    Arbol_Avl tree = new Arbol_Avl();
    tree.raiz = tree.insertar(tree.raiz, 13);
    tree.raiz = tree.insertar(tree.raiz, 32);
    tree.raiz = tree.insertar(tree.raiz, 43);
    tree.raiz = tree.insertar(tree.raiz, 12);
    tree.raiz = tree.insertar(tree.raiz, 34);
    tree.raiz = tree.insertar(tree.raiz, 61);
    tree.raiz = tree.insertar(tree.raiz, 64);
    tree.raiz = tree.insertar(tree.raiz, 11);    
    tree.inorden(tree.raiz);
    System.out.println("\n");
    tree.raiz = tree.Eliminar(tree.raiz, 11);
    tree.inorden(tree.raiz);
    System.out.println("\n");
    System.out.println(tree.Buscar(9));
    System.out.println("");
    tree.porNivel();
    System.out.println("\n");
    System.out.println(tree.raiz.der.altura);
       }
}
